-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: k5b206.p.ssafy.io    Database: heypapa_db
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article_hashtag`
--

DROP TABLE IF EXISTS `article_hashtag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article_hashtag` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `article_id` bigint DEFAULT NULL,
  `hashtag_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4adimje6fx9kut67u6jd9c174` (`article_id`),
  KEY `FKe3ccvxb3rjbjyugsttrkpabma` (`hashtag_id`),
  CONSTRAINT `FK4adimje6fx9kut67u6jd9c174` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`),
  CONSTRAINT `FKe3ccvxb3rjbjyugsttrkpabma` FOREIGN KEY (`hashtag_id`) REFERENCES `hashtag` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_hashtag`
--

LOCK TABLES `article_hashtag` WRITE;
/*!40000 ALTER TABLE `article_hashtag` DISABLE KEYS */;
INSERT INTO `article_hashtag` VALUES (79,34,32),(80,34,33),(81,34,34),(82,34,35),(83,34,36),(84,35,37),(85,35,38),(86,35,39),(87,35,40),(88,36,41),(89,36,42),(90,36,43),(91,36,44),(92,37,45),(93,37,46),(94,37,47),(95,37,48),(96,37,49);
/*!40000 ALTER TABLE `article_hashtag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-16 15:25:26
