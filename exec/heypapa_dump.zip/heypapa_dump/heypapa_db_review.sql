-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: k5b206.p.ssafy.io    Database: heypapa_db
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `article_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `calculate_time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8klm4xeeoxyah8iy90xt2svgp` (`article_id`),
  KEY `FKiyf57dy48lyiftdrf7y87rnxi` (`user_id`),
  CONSTRAINT `FK8klm4xeeoxyah8iy90xt2svgp` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`),
  CONSTRAINT `FKiyf57dy48lyiftdrf7y87rnxi` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (46,'저도 도전 해 봐야겠어요!','2021-11-15 13:52:53',34,26,NULL),(47,'아기가 너무 이쁘네요 딸이 쵝5!','2021-11-15 13:53:46',36,26,NULL),(48,'첫요리를 아직 도전도 못하고 있는데 ㅜㅜ 저도 주말에 도전~~!','2021-11-15 13:53:54',34,25,NULL),(49,'오 저도 한번 해봐야겠어요! 저희는 아직 성별은 몰라서 아들딸 둘다 하는걸로~~?','2021-11-15 13:58:16',36,27,NULL),(50,'미역국에 게까지... 정성이 가득입니다!','2021-11-15 13:58:28',34,28,NULL),(51,'태명이 너무 이뻐요 도담이 건강하게 자라렴~','2021-11-15 13:58:48',36,28,NULL),(52,'호랑이 같은 아들 낳기를 기원할게요!!','2021-11-15 13:59:03',35,28,NULL),(53,'초임파에서 이런 사진 건지기 힘들다는데! 대단하심','2021-11-15 14:00:51',37,27,NULL),(54,'호랑이 같은 딸은 어떠신지^^~~','2021-11-15 14:01:40',35,27,NULL);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-16 15:25:27
