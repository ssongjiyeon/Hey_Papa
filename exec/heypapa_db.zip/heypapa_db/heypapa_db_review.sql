-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: k5b206.p.ssafy.io    Database: heypapa_db
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `article_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `calculate_time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8klm4xeeoxyah8iy90xt2svgp` (`article_id`),
  KEY `FKiyf57dy48lyiftdrf7y87rnxi` (`user_id`),
  CONSTRAINT `FK8klm4xeeoxyah8iy90xt2svgp` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`),
  CONSTRAINT `FKiyf57dy48lyiftdrf7y87rnxi` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (46,'저도 도전 해 봐야겠어요!','2021-11-15 13:52:53',34,26,NULL),(47,'아기가 너무 이쁘네요 딸이 쵝5!','2021-11-15 13:53:46',36,26,NULL),(48,'첫요리를 아직 도전도 못하고 있는데 ㅜㅜ 저도 주말에 도전~~!','2021-11-15 13:53:54',34,25,NULL),(49,'오 저도 한번 해봐야겠어요! 저희는 아직 성별은 몰라서 아들딸 둘다 하는걸로~~?','2021-11-15 13:58:16',36,27,NULL),(50,'미역국에 게까지... 정성이 가득입니다!','2021-11-15 13:58:28',34,28,NULL),(51,'태명이 너무 이뻐요 도담이 건강하게 자라렴~','2021-11-15 13:58:48',36,28,NULL),(52,'호랑이 같은 아들 낳기를 기원할게요!!','2021-11-15 13:59:03',35,28,NULL),(53,'초임파에서 이런 사진 건지기 힘들다는데! 대단하심','2021-11-15 14:00:51',37,27,NULL),(54,'호랑이 같은 딸은 어떠신지^^~~','2021-11-15 14:01:40',35,27,NULL),(55,'리본이 포인트인거 같군요!!','2021-11-17 11:18:43',39,24,NULL),(56,'물려받은거 옷들이 퀄리티가 너무 좋네요 ㄷㄷ','2021-11-17 11:19:23',40,24,NULL),(57,'저도 그날 생각이 나네요ㅜㅜ 이제 곧 실물영접!!!','2021-11-17 11:20:15',38,24,NULL),(58,'오 어디서 구매하셨나요?','2021-11-17 11:28:00',42,24,NULL),(59,'솜씨가 대단한...','2021-11-17 11:28:21',41,24,NULL),(60,'와 대박 여기 어딘가요?','2021-11-17 11:32:08',43,26,NULL),(61,'와 좌표 좀 주세요','2021-11-17 11:32:31',43,28,NULL),(62,'너무 예쁘게 만드셨네요','2021-11-17 11:33:48',42,28,NULL),(63,'아기들은 금방 큰다고 계절마다 필요한 것만 사라고 하더라구요','2021-11-17 11:35:24',40,28,NULL),(64,'저는 이번에 제가 도전했는데 그냥 사다줄걸 그랬어요','2021-11-17 11:36:14',41,28,NULL),(65,'나중에는 가족 사진으로 또 찍으심 되겠어요','2021-11-17 11:37:05',39,28,NULL),(66,'코로나때문에 결혼식 미루셔서 슬프겠어요ㅜㅜ 내년에 찰떡이와 더 행복한 결혼식 하시길..~!','2021-11-17 11:38:34',44,24,NULL),(67,'저는 서울사는데 서울 근처인가요? 꼭 가보고싶네요','2021-11-17 11:38:56',43,24,NULL),(68,'저희 아내도 입덧때문에 샴푸를 매번 바꾸고있는데ㅜㅜ 한번 써보겠습니다 추천 감사드려요','2021-11-17 11:48:28',45,26,NULL),(69,'두달!!! 아기에게 목소리 많이 들려주세요','2021-11-17 11:49:06',44,26,NULL),(70,'와 멋져요!','2021-11-17 14:49:56',44,31,NULL),(71,'저도 스와들업 알고 보고 있는데 어디 껀가요!??','2021-11-17 14:53:50',49,28,NULL),(72,'어머 너무 인테리어 잘하셨네요 아늑해 보여요~','2021-11-17 14:54:12',46,28,NULL),(73,'저도 이렇게 메모장에 정리 해 놔야 겠습니다..','2021-11-17 14:54:40',47,25,NULL),(74,'여자 아이껀 이쁜게 많은데 남자껀 회색 뿐이네요 ㅜㅜ','2021-11-17 14:55:10',49,25,NULL);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-17 16:40:20
