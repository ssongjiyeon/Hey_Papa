-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: k5b206.p.ssafy.io    Database: heypapa_db
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `quiz_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `calculate_time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKde1ek5t1lq3k1un12f237iwl` (`quiz_id`),
  KEY `FK8kcum44fvpupyw6f5baccx25c` (`user_id`),
  CONSTRAINT `FK8kcum44fvpupyw6f5baccx25c` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKde1ek5t1lq3k1un12f237iwl` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (71,'d','2021-11-15 14:31:18',1,24,NULL),(72,'dd','2021-11-15 14:31:28',1,24,NULL),(73,'안녕 테스트!!!','2021-11-16 16:12:47',1,24,NULL),(74,'.','2021-11-16 22:09:22',1,29,NULL),(75,'와..몰랐는데 감사합니다','2021-11-17 11:28:40',2,26,NULL),(76,'헉;; 어제 첫째 딸 먹였는데.. 다음부터 조심해야겠네요','2021-11-17 11:37:40',17,26,NULL),(77,'조심해야겠네요!!','2021-11-17 11:38:37',20,26,NULL),(78,'오!! 어제 바나나사갔는데!!','2021-11-17 11:38:52',21,26,NULL),(79,'마사지 열심히 해줘야겠어요!!','2021-11-17 11:39:14',22,26,NULL),(80,'아니..한그릇은 먹어야되는거아닌가요??','2021-11-17 11:40:24',16,25,NULL),(81,'저도 감 좋아하는데 주의해야겠네요','2021-11-17 11:40:34',17,24,NULL),(82,'감 따러 가야겠네요','2021-11-17 11:40:45',17,25,NULL),(83,'선식을 종종 먹이시는 어른들이 계시더라구요;;','2021-11-17 11:40:53',18,24,NULL),(84,'와 딸기인줄 알았어요 맨날 딸기만 먹고싶어하길래 ㅎㅎ','2021-11-17 11:41:26',21,24,NULL),(85,'오오 조심해야겠네요','2021-11-17 11:41:28',19,25,NULL),(86,'파스대신 마사지를 열심히 해줘야겠네요','2021-11-17 11:42:30',22,24,NULL),(87,'한그릇도 안된다니ㅜㅜ 첫문제부터 너무 어렵','2021-11-17 11:46:28',16,26,NULL),(88,'영양소 중요!!!','2021-11-17 11:46:53',18,26,NULL),(89,'저는 따로 준비하는줄 알았어요','2021-11-17 11:47:07',19,26,NULL),(90,'호박이 붓기빼는데는 직빵이라던데','2021-11-17 11:47:30',20,26,NULL),(91,'꼭 다 익혀서 먹는거 중요하죠!','2021-11-17 13:11:55',24,25,NULL);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-17 16:40:20
