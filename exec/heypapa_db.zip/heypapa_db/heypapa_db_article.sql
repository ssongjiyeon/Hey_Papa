-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: k5b206.p.ssafy.io    Database: heypapa_db
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `calculate_time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbc2qerk3l47javnl2yvn51uoi` (`user_id`),
  CONSTRAINT `FKbc2qerk3l47javnl2yvn51uoi` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (34,'아내를 위한!! 태어날 우리 튼튼이를 위한!! 첫 요리!!\n앞으로 자주자주 해줄께~♥','2021-11-15 13:38:56','article/24-2021-11-15-04-38-56-미역국.jpg','2021-11-15 13:38:56',24,NULL),(35,'My son 쑥쑥이 ?? 호랑이처럼 건강하게 자라렴\n5달 뒤에 건강하게 만나자!!','2021-11-15 13:48:58','article/26-2021-11-15-04-48-58-어릴때사진.png','2021-11-15 13:48:58',26,NULL),(36,'우리 베이비 도담이 미래 얼굴 예측?\n아내가 저 99프로에 자기 1프로인거 같다고\n해서 다시 해봤는데도 별 차이가 없더라는??','2021-11-15 13:52:55','article/25-2021-11-15-04-52-55-울애기_여자.PNG','2021-11-15 13:52:55',25,NULL),(37,'안녕? 와이프가 보내준 초음파 사진 .. 우리 찰떡이 첫 인사에요!!','2021-11-15 13:56:50','article/28-2021-11-15-04-56-50-초음파사진.png','2021-11-15 13:56:50',28,NULL),(38,'아내의 임신을 처음으로 확인한 날??','2021-11-17 11:12:47','article/28-2021-11-17-02-12-46-임신확인.PNG','2021-11-17 11:12:47',28,NULL),(39,'제주도가서 6개월차에 남겨 본 아내 사진 ?','2021-11-17 11:15:01','article/25-2021-11-17-02-15-00-임신사진.png','2021-11-17 11:15:01',25,NULL),(40,'사촌누나에게 물려받았어요!\n외출복은 애기 크는거 봐서 사도 되겠죠?','2021-11-17 11:18:44','article/25-2021-11-17-02-18-43-옷.png','2021-11-17 11:18:44',25,NULL),(41,'울 와이프가 만들어줌!!!\n','2021-11-17 11:22:29','article/25-2021-11-17-02-22-29-빼빼로.png','2021-11-17 11:22:29',25,NULL),(42,'우리 쑥쑥이 애착인형 만들기','2021-11-17 11:26:27','article/26-2021-11-17-02-26-27-애착인형.png','2021-11-17 11:26:27',26,NULL),(43,'오늘은 튼튼이가 고기를 먹고싶어해서 소고기 외식을~~ 돼지고기는 입덧때문에 잘 못 먹더만 소고기는 잘 드시는^^;;;','2021-11-17 11:27:39','article/24-2021-11-17-02-27-38-외식.PNG','2021-11-17 11:27:39',24,NULL),(44,'저 두달 있으면 아빠됩니다.\n코로나 시국이라 결혼식은 내년에 해서 너무 아쉽지만..\n마니마니 축하해주세요^^','2021-11-17 11:32:01','article/28-2021-11-17-02-32-01-두달.PNG','2021-11-17 11:32:01',28,NULL),(45,'임산부 탈모 전용샴푸 로마 너리싱 샴푸\n제가 와이프 몰래 써봤습니다 ㅎㅎㅎ\n자극적인 냄새도 없어서 냄새때문에 입덧하시는 분들한테도 추천입니다. 거품도 충분히 나오고 !!\n다들 와이프 선물로 추천해요~~','2021-11-17 11:45:31','article/24-2021-11-17-02-45-30-탈모샴푸.PNG','2021-11-17 11:45:31',24,NULL),(46,'울 아가 방 몽땅 다 내스타일??\n플라워자수 블랭킷보고 완전 반해버려서\n다 마리데에서 주문했는데\n이와중에 운좋게 침대패드는 이벤트당첨되서 선물받음\n패드사이즈 완전 안성맞춤이라 툭 깔아주면 끝!\n튼튼이 증말 복덩이?','2021-11-17 14:40:25','article/24-2021-11-17-05-40-24-아기방사진.png','2021-11-17 14:40:35',24,NULL),(47,'아내가 임신했을 때 남편이 알아야할 것 정리!\n중요한 것들 메모장에 정리해 두자!!','2021-11-17 14:43:38','article/26-2021-11-17-05-43-38-알아두어야할것사진.png','2021-11-17 14:43:38',26,NULL),(49,'와이프를 위해 미리 장만한 스와들업!!\n혹시나 튼튼이가 불편해 할 수도 있을 것 같아서\n제일 작은 사이즈로 두개만 미리 구매해봤어용\n튼튼이한테 잘 맞으면 더 큰사이즈들도 차차 구매하려구요!','2021-11-17 14:52:55','article/24-2021-11-17-05-52-54-스와들업사진.jfif','2021-11-17 14:52:55',24,NULL),(50,'미리 아기 옷 준비! 얼른 만났으면!','2021-11-17 15:44:55','article/31-2021-11-17-06-44-55-대담이_게시글.jpg','2021-11-17 15:44:55',31,NULL);
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-17 16:40:20
